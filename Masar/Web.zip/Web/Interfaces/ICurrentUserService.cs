﻿namespace Web.Interfaces
{
    public interface ICurrentUserService
    {
        int GetUserId();
    }
}
