﻿namespace Web.ViewModels.Instructor.Dashboard;

public class InstructorGeneralStatsViewModel
{
    public int TotalCourses { get; set; }
    public int TotalStudents { get; set; }
    public float AverageRating { get; set; }
    public int CompletionRate { get; set; }
}
