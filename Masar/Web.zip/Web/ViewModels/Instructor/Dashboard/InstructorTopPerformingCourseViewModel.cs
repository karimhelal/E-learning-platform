﻿namespace Web.ViewModels.Instructor.Dashboard;

public class InstructorTopPerformingCourseViewModel
{
    public string Title { get; set; }
    public int StudentsEnrolled { get; set; }
    public float AverageRating { get; set; }
}
