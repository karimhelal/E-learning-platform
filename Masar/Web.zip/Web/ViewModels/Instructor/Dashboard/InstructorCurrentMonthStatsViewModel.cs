﻿namespace Web.ViewModels.Instructor.Dashboard;

public class InstructorCurrentMonthStatsViewModel
{
    public int NewStudents { get; set; }
    public int Completions { get; set; }
    public int NewReviews { get; set; }
}
